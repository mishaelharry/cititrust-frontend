import React from 'react';
import {Redirect} from 'react-router-dom';
import axios from 'axios';

const info = {
    email:  'abim3@gmail.com',
    password: 'olatomide'
}
class Upload extends React.Component{


    cashnow = (e) =>{
        e.preventDefault();
        this.props.history.push('/cashnow')

    }

    pocketmoni = (e) => {
        e.preventDefault();
        this.props.history.push('/pocket_form1')

    }

    accrelex = (e) => {
        e.preventDefault();
        this.props.history.push('/form1')

    }

    render(){
        return(
            <>
       
                <div className="container d-flex justify-content-end align-item-center">
                    <h4  className="mr-auto pt-2 font-weight-bold"><span className="text-dark">SEMBIC REALNET FORMS</span></h4>
                    <a href="/register" className="pr-4 pt-2">Register</a>
                    <a href="/login" className="pt-2 pr-4">Login</a>
                    <a href="#" className="pt-2">Faq</a>
                </div>
                <div className="container mt-5 pt-2 d-flex justify-content-center align-item-center">
                
                    <div className="d-flex justify-content-center align-items-center">
    
                        <div className="col-md-10 offset-1" >
                        <p className="text-center text-primary">WELCOME TO REALAGENT NETWORK.</p>
                        <div className="col-md-12 mt-5 text-center">
                            <p>RealAGENT is a sembic Int'l Ltd initiative. The core essence of realAGENT is to aggregate Terminal services and other related services
                                .REALAGENT is also an agent network management service ofSembic Int'l Ltd. Our major desire is to drive financial inclusion. So, we have strategic 
                                partners with various platform operators/Super Agent to deliver quality to our network.
                            </p>
                        <div class="row text-center">
                        
                        <div className="col-md-4 pb-4">
                        <button className="btn btn-lg btn-success text-center" onClick={this.cashnow} >CASHNOWNOW <br />LOAN</button>
                        </div>
                        <div className="col-md-4 pb-2">
                        <button className="btn btn-lg btn-info text-center " onClick={this.accrelex}>ACCRELEX REGISTRATION</button>

                        </div><br />
                        <div className="col-md-4">
                        <button className="btn btn-lg btn-danger text-center " onClick={this.pocketmoni}>POCKETMONI REGISTRATION</button>


                        </div>
                        
                    </div>

                        </div>
                      
                            
                        </div>
                    </div>
                </div>
            </>

        )

    }
}
export default Upload

