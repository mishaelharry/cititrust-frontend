import React from 'react';

class Mod extends React.Component{
   render(){

       return(
           <>
           <hr/ >
           </>
       )
   }
}
export default Mod;