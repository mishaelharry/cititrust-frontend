/*!

=========================================================
* Paper Dashboard React - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-react
* Copyright 2019 Creative Tim (https://www.creative-tim.com)

* Licensed under MIT (https://github.com/creativetimofficial/paper-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
/*eslint-disable*/
import React from "react";
// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
   Label, FormText } from 'reactstrap';

   import {Redirect } from 'react-router-dom'
 
   import axios from 'axios'

class Byte extends React.Component {
  state = {
    load: false,
    status: false,
    username: '',
    password: '',
    token: false,
    catch:false
    
  };

  onChange = (e) => {
    const {name, value} = e.target;
    this.setState({
      [name] : value
    })

  }

  onClick = (e) => {
    e.preventDefault();
    this.setState({
      visible: true
    })
  }

  login = (e) =>{
    e.preventDefault();
    sessionStorage.setItem('token',2)
    this.props.history.push('/home')
    // console.log('clicked')
    // const login ={
    //   username: this.state.username,
    //   password: this.state.password
    // };
    // if( login.username || login.password){
    //   this.setState({
    //     load: true
    //   })
    //   axios.post(`http://34.246.178.255:13006/api/byteproof/v1/useraccess/userlogin`, login,{
    //   auth: {
    //     username: 'ByteClient2',
    //     password: 'Password'
    //   }
    // }).
    // then((res)=> {
    //   console.log(res.data.result.usertoken)
    //   sessionStorage.setItem('token',res.data.result.usertoken)
    //   this.setState({
    //     token: true
    //   })
    //   this.props.history.push('/admin/dashboard')
      
    // }).
    // catch((err) => {
    //   console.log(err)
    //   this.setState({
    //     catch: true, load:!this.state.load
    //   })
    //   setTimeout(()=>{
    //     this.setState({
    //       catch: false
    //     })
    //   },800)
    // })

    // }
    // else{
    //   this.setState({
    //     status: true
    //   })
    //   setTimeout(()=>{
    //     this.setState({
    //       status: false
    //     })
    //   },1000)
    // }
    
  }

 
 
  render() {
    // if(sessionStorage.getItem('token')){
    //   return (
    //     <Redirect to = "admin/dashboard" />
    //   )
    // }
    // if(this.state.token){
    //   return(
    //     <Redirect to="admin/dashboard" />
    //   )
    // }
    return (
      <>
        <div className="content register-bg">
          <br />
          <br />
          <br />
          <br />
          
  <div className="mt-5  d-flex justify-content-center align-items-center">
  <div class="card" style={{width: "20rem"}}>
  <p className="alert alert-danger mb-0 text-white text-center font-weight-bold">Sembic Login Page</p>
  <div class="card-body">
    {this.state.status && <p class="card-text text-danger text-center">Fields Cannot be Empty</p>}
    {this.state.catch && <p class="card-text text-danger text-center ">Invalid Login</p>}
    <Form className="col-md-12 pt-1">
      <FormGroup>
        <Label for="exampleEmail" className="text-left">Name</Label>
        {!this.state.status ? <Input type="email" name="username" id="exampleEmail"  onChange={this.onChange} /> : <Input type="email" className="error"  name="username" id="exampleEmail"  onChange={this.onChange} /> }
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="text-left">Phone Number</Label>
    {!this.state.status ? <Input type="password" name="password" id="examplePassword"  onChange={this.onChange} /> : <Input type="password" name="password" id="examplePassword" className="error" onChange={this.onChange} /> }
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="text-left">Email</Label>
    {!this.state.status ? <Input type="password" name="password" id="examplePassword"  onChange={this.onChange} /> : <Input type="password" name="password" id="examplePassword" className="error" onChange={this.onChange} /> }
      </FormGroup>
      <br />
     
      {this.state.load ? 
      <button className ="btn btn-default btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
     Logging In...
    </button> :
      <Button onClick={this.onClick} onClick={this.login} color="info btn-block">Login</Button>
      
      }
      
    </Form>
  </div>
</div>
      
                  </div>
                 <br />
                  <br />
                  <br />
                  <br />
                  <br />
                  <br />
                  <br />
                  <br />
                
              
         
        </div>
      </>
    );
  }
}

export default Byte;
