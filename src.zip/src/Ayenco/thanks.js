import React from 'react';
class Thanks extends React.Component{
    render(){
        return(
            <>
            <div className="thanks text-success">
                <h3>THANKS FOR REGISTERING</h3>
                <p>YOUR DETAILS HAS BEEN SUBMITTED</p>
                
            </div>


            
            </>
        )
    }
}
export default Thanks;