import React from 'react';
import {Redirect} from 'react-router-dom';
import axios from 'axios';

const info = {
    email:  'abim3@gmail.com',
    password: 'olatomide'
}
class Home extends React.Component{


    cashnow = (e) =>{
        e.preventDefault();
        this.props.history.push('/cashnow')

    }

    pocketmoni = (e) => {
        e.preventDefault();
        this.props.history.push('/pocket_form1')

    }

    accrelex = (e) => {
        e.preventDefault();
        this.props.history.push('/form1')

    }

    render(){
        if(!sessionStorage.getItem('token')){
            this.props.history.push('/login')
        }
        return(
            <>
       
                <div className="container d-flex justify-content-end align-item-center nav2">
                    <h4  className="mr-auto pt-2 font-weight-bold"><span className="text-dark">SEMBIC REALAGENT NETWORK</span></h4>
                    <a href="/register" className="pt-2">Welcome Victor!</a>
                    <a href="/" className="pl-3 pt-2">Logout</a>
                  
                </div>
                <div className="container mt-5 pt-2 d-flex justify-content-center align-item-center">
                    <div className="d-flex justify-content-center align-items-center">
                        <div className="col-md-10 txt-center" >
                        <i class="fa fa-shield text-center fa-3x d-flex justify-content-center"></i>
                        <p className="text-center text-primary font-weight-bold">WELCOME TO REALAGENT NETWORK.</p>
                        <div className="col-md-12 mt-2 text-center">
                            <p>RealAGENT is a sembic Int'l Ltd initiative. The core essence of realAGENT is to aggregate Terminal services and other related services
                                .REALAGENT is also an agent network management service ofSembic Int'l Ltd. Our major desire is to drive financial inclusion. So, we have strategic 
                                partners with various platform operators/Super Agent to deliver quality to our network.
                            </p>
                            <hr />
                            <br />
                            <i class="fa fa-tint fa-4x"></i>
                            <p className="text-center text-primary font-weight-bold">WHAT DO WE DO ?</p>
                            <br />
                            <div className="row">
                                <div className="col-md-4">
                                
                                <div class="card bg-info" style={{maxWidth: "18rem"}}>
  <div class="card-header text-center text-white"><i class="fa fa-star"></i></div>
  <div class="card-body text-primary">
    <h5 class="card-title text-white">Identify Agents.</h5>
  
  </div>
</div>
                          
                                </div>
                                <div className="col-md-4">
                               
                                <div class="card bg-info" style={{maxWidth: "18rem"}}>
  <div class="card-header text-center text-white"> <i class="fa fa-star"></i></div>
  <div class="card-body text-primary">
    <h5 class="card-title text-white">Vet Agents</h5>
    
  </div>
</div>
                                </div>
                                <div className="col-md-4">
                               
                                <div class="card bg-info" style={{maxWidth: "18rem"}}>
  <div class="card-header text-center text-white"> <i class="fa fa-star"></i></div>
  <div class="card-body text-primary">
    <h5 class="card-title text-white">Train Agents</h5>
    
  </div>
</div>
                            
                                </div>
                                <div className="col-md-4">
                               
                                <div class="card bg-info" style={{maxWidth: "18rem"}}>
  <div class="card-header text-white"> <i class="fa fa-star"></i></div>
  <div class="card-body text-primary">
    <h5 class="card-title text-white">Identify Agents</h5>
   
  </div>
</div>
                                </div>
                                <div className="col-md-4">
                                
                                <div class="card bg-info" style={{maxWidth: "18rem"}}>
  <div class="card-header text-white"><i class="fa fa-star"></i></div>
  <div class="card-body text-primary">
    <h5 class="card-title text-white">Monitor Agents</h5>
    
  </div>
</div>
                            
                                </div>
                                <div className="col-md-4">
                             
                                <div class="card bg-info" style={{maxWidth: "18rem"}}>
  <div class="card-header text-white" ><i class="fa fa-star"></i></div>
  <div class="card-body text-primary">
    <h5 class="card-title text-white">Manage Agents</h5>
 
  </div>
</div>
                                
                                </div>
                            
                            </div>
                            <hr />
                            <br />
                            <i class="fa fa-fire fa-4x"></i>
                            <p className="text-center text-primary font-weight-bold pt-3">OUR SERVICES</p>
                            <div className="row">
                                <div className="col-md-4">
                                <div class="card">
      <div class="card-body bg-dark text-white">
        <h5 class="card-title text-white font-weight-bold">CASHNOWNOW AGENT FORM</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a onClick={this.cashnow} class="btn btn-primary">APPLY</a>
        
      </div>
    </div>
 
                                </div>
                                <div className="col-md-4">
                                <div class="card">
      <div class="card-body bg-dark text-white">
        <h5 class="card-title text-white font-weigh-bold ">GLOBAL ACCRELEX AGENT </h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a onClick={this.accrelex} class="btn btn-primary">APPLY</a>
      </div>
    </div>
                                </div>
                                <div className="col-md-4">
                                <div class="card">
      <div class="card-body bg-dark text-white">
        <h5 class="card-title text-white font-weight-bold">POCKETMONEY AGENT</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a onClick={this.pocketmoni} class="btn btn-primary">APPLY</a>
      </div>
    </div>
                                </div>
                               
                            
                            </div>
                            <br />
                            <br />
                            <br />
                            <br />
                        


                            <footer className="text-danger text-center mt-5">sembic &copy;2020</footer>


                        </div>
                      
                            
                        </div>
                    </div>
                    
                </div>
            </>

        )

    }
}
export default Home

