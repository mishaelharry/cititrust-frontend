/*!

=========================================================
* Paper Dashboard React - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-react
* Copyright 2019 Creative Tim (https://www.creative-tim.com)

* Licensed under MIT (https://github.com/creativetimofficial/paper-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React from "react";
import { NavLink } from "react-router-dom";
import { Nav, Collapse, Button, CardBody, Card } from "reactstrap";
// javascript plugin used to create scrollbars on windows
import PerfectScrollbar from "perfect-scrollbar";
import logo from "../../assets/img/g5453.png";
import logo2 from "../../assets/img/zenith.png";

var ps;

class Sidebar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
      isOpen2: false,
      collapse: false,
      pcBar: true,
      color:false,
      hovColor: false,
      hovColor2: false,
      hovColor3: false,
      hovColor4: false
    };
    this.activeRoute.bind(this);
    this.sidebar = React.createRef();
    this.toggle.bind(this);
    this.toggle2.bind(this);
  }

  hover = (e) => {
    e.preventDefault();
    this.setState({
      hovColor: true
    })

  }
  hover2 = (e) => {
    e.preventDefault();
    this.setState({
      hovColor2: true
    })

  }
  hover3 = (e) => {
    e.preventDefault();
    this.setState({
      hovColor3: true
    })

  }
  hover4 = (e) => {
    e.preventDefault();
    this.setState({
      hovColor4: true
    })

  }

  toggle = e => {
    e.preventDefault();
    this.setState({
      isOpen: !this.state.isOpen
    });
  };

  out  = () => {
    this.setState({
      hovColor: false
    })
  }
  out2  = () => {
    this.setState({
      hovColor2: false
    })
  }
  out3  = () => {
    this.setState({
      hovColor3: false
    })
  }
  out4  = () => {
    this.setState({
      hovColor4: false
    })
  }
  toggle3 = e => {
    e.preventDefault();
    this.setState({
      isOpen2: !this.state.isOpen2
    });
  };

  slide = () => {
    // document.documentElement.classList.toggle("main-panel");
    // this.sidebarToggle.current.classList.toggle("toggled");
    let { pcBar } = this.state;
    var all = document.getElementsByClassName("main-panel");
    var all1 = document.getElementsByClassName("sidebar");
    var dash = document.getElementsByClassName("vert");
    this.setState({ pcBar: !pcBar }, () => {
      if (!pcBar) {
        for (var i = 0; i < all.length; i++) {
          all[i].style.width = `calc(100% - 45px)`;
        }
        for (var i = 0; i < all1.length; i++) {
          all1[i].style.width = `45px`;
          this.setState({
            color: true
          })
        }
        for (var i = 0; i < dash.length; i++) {
          dash[i].style.marginLeft = "40px";
          
        }
      } else {
        for (var i = 0; i < all.length; i++) {
          all[i].style.width = `calc(100% - 235px)`;
          all[i].style.position = `relative`;
        }
        for (var i = 0; i < all1.length; i++) {
          all1[i].style.width = "235px";
        
          this.setState({
            color: false
          })
        }
        for (var i = 0; i < dash.length; i++) {
          dash[i].style.marginLeft = "195px";
     
        }
      }
    });
  };

  toggle2 = e => {
    e.preventDefault();
    this.setState({
      isOpen2: !this.state.isOpen2
    });
  };

  // verifies if routeName is the one active (in browser input)
  activeRoute(routeName) {
    return this.props.location.pathname.indexOf(routeName) > -1 ? "active" : "";
  }
  componentDidMount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(this.sidebar.current, {
        suppressScrollX: true,
        suppressScrollY: false
      });
    }
    this.setState({
      color: true
    })
  }
  componentWillUnmount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps.destroy();
    }
   
  }
  render() {
    return (
      <>
     
      <div
        className="sidebar bg"
        data-color={this.props.bgColor}
        data-active-color="{this.props.activeColor}"
        onMouseLeave={this.slide}
        onMouseEnter={this.slide}
        
      >
      
       {this.state.color ? 
        <div className="logo mb-1 mt-0" >
           <a
            href="/admin/dashboard"
            className="simple-text logo-mini"
          >
            <div >
              <img src={logo2} alt="react-logo" className="w-49 pt-2" style={(this.state.color)?{maxHeight:'100px'}:{maxHeight:'50px', marginLeft: '90px' }}/>
            </div>
          </a>
        </div> 
        :
        <div className="simple-text py-2 image-underbg " >
        <a
         href="/admin/dashboard"
         className="simple-text logo-mini"
       >
         <div >
           <img src={logo2} alt="react-logo" className="w-49 pt-2" style={(this.state.color)?{maxHeight:'100px'}:{maxHeight:'50px', marginLeft: '90px' }}/>
         </div>
       </a>
     </div>
       }
       
     
      
        <div className="sidebar-wrapper" ref={this.sidebar} >
          <Nav className="hover pl-0 mt-4" >
            <li className="pl-0" >
              <NavLink
                to="/admin/dashboard"
                className="nav-link ml-0 "
                activeClassName="choosen"
                onMouseOver={this.hover}
                onMouseLeave ={this.out}
              >
              {this.state.hovColor ? 
                <i className="text-white fa fa-home pr-3 pb-0" >
                  <span className="pl-3 text-white">DASHBOARD</span>
                </i>
                :
                <i className="faa fa fa-home pr-3 pb-0" >
                <span className="pl-3 text-dark">DASHBOARD</span>
              </i>
              }
              </NavLink>
             
            </li>
            <br />
            <li className="pl-0">
              <NavLink
                to="#"
                className="nav-link ml-0  text-white"
                activeClassName="choosen"
                onClick={this.toggle3}
                onMouseOver={this.hover2}
                onMouseLeave ={this.out2}
              >
              {this.state.hovColor2 ? 
                 <i className="text-white fa fa-eye">
                  <span className="pl-3 text-white">GL RECONCILIATION {" "}
                    <i
                      className="fa fa-plus-circle ml-0"
                      onClick={this.toggle3}
                    ></i></span>
                </i>:
                  <i className="faa fa fa-eye">
                  <span className="pl-3 text-dark">GL RECONCILIATION {" "}
                    <i
                      className="fa fa-plus-circle ml-0"
                      onClick={this.toggle3}
                    ></i></span>
                </i>

              }
              </NavLink>
              <Collapse
                isOpen={this.state.isOpen2}
                className="text-info ml-2 mt-0"
              >
                <div className="accord pt-0 text-white">
                  <NavLink
                    to="/admin/glr_class"
                    activeClassName="choosen"
                    className="text-dark nav-link pl-5"
                
                  >
                   Class
                  </NavLink>
                  <NavLink
                    to="/admin/glr_account"
                    activeClassName="choosen"
                    className="text-dark nav-link pl-5"
                   
                  >
                    Accounts
                  </NavLink>
                  <NavLink
                    to="/admin/glr_component"
                    activeClassName="choosen"
                    className="text-dark nav-link pl-5"
                  
                  >
        
                   Components
                  </NavLink>
                  <NavLink
                    to="/admin/glr_items"
                    activeClassName="choosen"
                    className="text-dark nav-link pl-5"
                    
                  >
                  
                  Items
                  </NavLink>
                  <NavLink
                    to="/admin/glr_matching"
                    activeClassName="choosen"
                    className="text-dark nav-link pl-5"
                  >
                    Matching Sets
                  </NavLink>
                  <NavLink
                    to="/admin/upgrade"
                    activeClassName="choosen"
                    className="text-dark nav-link pl-5"
                  >
                    Proof Reports
                  </NavLink>
                </div>
              </Collapse>
            </li>
            <br />
            <li className="pt-0">
              <NavLink
                to="#"
                className="nav-link ml-0  text-dark"
                activeClassName="choosen"
                onMouseOver={this.hover3}
                onMouseLeave ={this.out3}
              >
              {this.state.hovColor3 ?
                <i className="text-white fa fa-exchange">
                  <span className="pl-3 text-white">DATA LOAD DASHBOARD {" "}
                    <i
                      className=" fa fa-plus-circle ml-0"
                      onClick={this.toggle3}
                    ></i></span>
                </i>:
                 <i className="faa fa fa-exchange">
                 <span className="pl-3 text-dark">DATA LOAD DASHBOARD {" "}
                   <i
                     className=" fa fa-plus-circle ml-0"
                     onClick={this.toggle3}
                   ></i></span>
               </i>

              }
              </NavLink>
            </li>
            <br />
            <li className="pt-0">
              <NavLink
                to="/login"
                className="nav-link ml-0  text-white"
                activeClassName="choosen"
                onMouseOver={this.hover4}
                onMouseLeave ={this.out4}
              >
              {this.state.hovColor4 ? 
                <i className="text-white fa fa-sign-out">
                  <span className="text-white pl-3">LOG OUT</span>
                </i>:
                 <i className="faa fa fa-sign-out">
                 <span className="text-dark pl-3">LOG OUT</span>
               </i>

              }
              </NavLink>
            </li>
          </Nav>
        </div>
      </div>
      </>
    );
  }
}

export default Sidebar;
