/*!

=========================================================
* Paper Dashboard React - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-react
* Copyright 2019 Creative Tim (https://www.creative-tim.com)

* Licensed under MIT (https://github.com/creativetimofficial/paper-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import Dashboard from "./views/Dashboard.jsx";
import Notifications from './views/notify'
import Icons from "./views/Icons.jsx";
import GLRClass from './views/GL_modules/glrclass'
import GLRAccounts from './views/GL_modules/glraccounts'
import GLRComponents from './views/GL_modules/glrcompo'
import GLRItems from './views/GL_modules/glritems'
import GLRMatching from './views/GL_modules/glrmatching'
import GLRDash from './views/GL_modules/glrdash'
import GLRProof from './views/GL_modules/glrproof'
import TableList from "./views/Tables.jsx";
import Maps from "./views/Map.jsx";
import UserPage from "./views/User.jsx";
import UpgradeToPro from "./views/Upgrade.jsx";
import Atm from "./views/Atm";
import GL from "./views/GL";
import GLM from "./views/GLM";

var routes = [
  {
    path: "/dashboard",
    name: "ByteProof Dashboard",
    icon: "nc-icon nc-bank",
    component: Dashboard,
    layout: "/admin"
  },

  {
    path: "/notify",
    name: "ByteProof Dashboard",
    icon: "nc-icon nc-bank",
    component: Notifications,
    layout: "/admin"
  },

  {
    path: "/atm_content_management",
    name: "EJ Dashboard",
    icon: "nc-icon nc-bank",
    component: Atm,
    layout: "/admin"
  },
 
  {
    path: "/Ej_Trans_search",
    name: "EJ Transaction Search",
    icon: "nc-icon nc-bank",
    component: GL,
    layout: "/admin"
  },
  {
    path: "/GL_management",
    name: "EJ Bulk Transaction Search",
    icon: "nc-icon nc-bank",
    component: GLM,
    layout: "/admin"
  },
  {
    path: "/icons",
    name: "Icons",
    icon: "nc-icon nc-diamond",
    component: Icons,
    layout: "/admin"
  },
  {
    path: "/maps",
    name: "Maps",
    icon: "nc-icon nc-pin-3",
    component: Maps,
    layout: "/admin"
  },

  {
    path: "/user-page",
    name: "User Profile",
    icon: "nc-icon nc-single-02",
    component: UserPage,
    layout: "/admin"
  },
  {
    path: "/gl_proofing",
    name: "Proof Dashboard",
    icon: "nc-icon nc-tile-56",
    component: GLRDash,
    layout: "/admin"
  },
 
   {
    path: "/glr_class",
    name: "ByteProof",
    icon: "nc-icon nc-tile-56",
    component: GLRClass,
    layout: "/admin"
  },
  {
    path: "/glr_account",
    name: "ByteProof ",
    icon: "nc-icon nc-tile-56",
    component: GLRAccounts,
    layout: "/admin"
  },
  {
    path: "/glr_component",
    name: "ByteProof ",
    icon: "nc-icon nc-tile-56",
    component: GLRComponents,
    layout: "/admin"
  },
  {
    path: "/glr_items",
    name: "ByteProof",
    icon: "nc-icon nc-tile-56",
    component: GLRItems,
    layout: "/admin"
  },
  {
    path: "/glr_matching",
    name: "ByteProo",
    icon: "nc-icon nc-tile-56",
    component: GLRMatching,
    layout: "/admin"
  },
  {
    path: "/glr_proof",
    name: "ByteProof",
    icon: "nc-icon nc-tile-56",
    component: GLRProof,
    layout: "/admin"
  },
  {
    path: "/tables",
    name: "Table List",
    icon: "nc-icon nc-tile-56",
    component: TableList,
    layout: "/admin"
  },
  
  {
    pro: true,
    path: "/upgrade",
    name: "Upgrade to PRO",
    icon: "nc-icon nc-spaceship",
    component: UpgradeToPro,
    layout: "/admin"
  }
  
];
export default routes;
