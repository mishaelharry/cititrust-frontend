import React from 'react'
import MUIDataTable from 'mui-datatables'
class Table extends React.Component{
    render() {
        console.log(this.props)
        return (
            <div>
    
            </div>
        );
    }
}

export default Table
   