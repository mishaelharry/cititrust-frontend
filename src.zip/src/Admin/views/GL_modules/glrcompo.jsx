
import React from "react";
// react plugin used to create charts
import { Line, Pie,Bar,Radar ,Doughnut} from "react-chartjs-2";
import { Helmet } from 'react-helmet'
// reactstrap components
import Childoptions from './child'
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row
 ,Button,
  Form, FormGroup, Label, Input, FormText,
  Col
 
} from "reactstrap";
// core components
import {
  dashboard24HoursPerformanceChart,
  dashboardEmailStatisticsChart,


  dashboardNASDAQChart
} from "../../variables/charts";
import axios from 'axios'
import { Modal } from 'antd';
import Header from '../../components/Navbars/DemoNavbar'
import MUIDataTable from "mui-datatables";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import {compoSearch, compoAdd} from '../../module_columns/component'

class GLRComponents extends React.Component {
  state = {
    modal3: false,
    createModal: false,
    status: false,
    status2:false,
    dataValue: "int",
    selectedAccount: '',
    apiStatus: false,
    active: false,
    classNames: [],
    accountNames: [],
    specialAccount: [],
    data: [],
    apiStatus2: false,
    bankNames: [],
    componentname: '',
    componentdescription: '',
    componentbalance: '',
    accountname:'',
    componentside:'',
    bank:'',
    created: '',
    updated:''
  }

  toggle = (e) => {
    e.preventDefault();
    this.setState({
      modal3: !this.state.modal
    })
  }

  handleOk = e => {
    console.log(e);
    this.setState({
      modal3: false,
    });
  };

  handleCancel = e => {
    console.log(e);
    this.setState({
      modal3: false,
    });
  };

  handleOk2 = e => {
    console.log(e);
    this.setState({
      createModal: false,
    });
  };

  handleCancel2 = e => {
    console.log(e);
    this.setState({
      createModal: false,
    });
  };

  
  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({
      [name] :  value
    })

  }

  compChange = ({ target: { value } }) => {
    this.setState({ dataValue: value });
  }


  getMuiTheme = () => createMuiTheme({
    overrides: {
      MUIDataTableHeadCell: {
        fixedHeaderOptions: {
          backgroundColor: `blue !important`,
        }
      },
      MUIDataTableHead: {
        root: {
          backgroundColor: `#1D252D !important` ,

        }
      },
      MuiTableCell: {
        root: {
            padding: '3px 3px 0 0'
        },
        body: {
            fontSize: '13px',
            textAlign: 'left'
        }
    },
      MUIDataTableBodyRow: {
        root: {
          '&:nth-child(odd)': { 
            backgroundColor: '#e3e9ed',
            data: {
              whiteSpace: 'nowrap'
            }
            
          }
        }
      },
      MUIDataTableSelectCell: {
        headerCell: {
          backgroundColor: '#000'
        },
        checked: `lightcoral !important`
      },
      MUIDataTablePagination: {
        root: {
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center"
        },
        caption: {
          fontSize: 12
        }
      }
    }
  })

    toggle2 = (e) => {
      e.preventDefault();
      this.setState({
        createModal: !this.state.createModal
      })

  }

  getAllClassNames = () => {
    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/class/getAllClassNames`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
      console.log(res.data)
      this.setState({
        classNames: res.data
      }) 
    }).
    catch((err) => {
    
    })

  }

  getBanks = () => {
    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpbank/getAllBankNames`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
      console.log(res.data)
      this.setState({
        bankNames: res.data
      }) 
    }).
    catch((err) => {
    
    })

  }

 

  getAccountNames = () => {

    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpaccount/getAllAccountNames`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {

      this.setState({
        accountNames: res.data
      }) 
    }).
    catch((err) => {
    
    })
  }

  
  specialAccount =() => {
    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpaccount/getAllAccountNamesByClass?classname=Verve Receivable`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
     
      this.setState({
        specialAccount: res.data
      }) 
    }).
    catch((err) => {
    
    })

  }


  

  compoSearch = (e) => {
    e.preventDefault();  
    console.log(this.state.selectedAccount)
    this.setState({
      status: true
    })
      axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpcomponent/getBpComponent?accountname=${this.state.selectedAccount}&page=0&size=10`,{
        auth: {
          username: 'ByteClient2',
          password: 'Password'
        }
      }).
      then((res)=> {
        console.log(res.data)
        this.setState({
          status: false, data: res.data.result, message: res.data.message, modal3: false, apiStatus: res.data.status, apiStatus2: false
        }) 
      }).
      catch((err) => {
        console.log(err)
        this.setState({
          apiError: true
        })
        setTimeout(()=> {
          this.setState({
            apiError: false
          })
        },2000)
        
      })

    
   
  }

  compoCreate = (e) => {
    e.preventDefault();
    const compotData = {
      componentname: this.state.componentname,
      componentdescription: this.state.componentdescription,
      componentbalance: this.state.componentbalance,
      accountname: this.state.accountname,
      componentside: this.state.componentside,
      bank: this.state.bank,
      createdBy: this.state.created,
      updatedBy: this.state.updated
    }
    console.log(compotData)

   this.setState({
     status2: true
   })
      axios.post(`http://34.246.178.255:13006/api/byteproof/v1/bpcomponent/create`,compotData,{
        auth: {
          username: 'ByteClient2',
          password: 'Password'
        }
      }).
      then((res)=> {
        console.log(res.data)  
        this.setState({
          status2: false, createModal:false, apiStatus2: res.data.status, msg: true
        })
        setTimeout(()=>{
          this.setState({
            msg: false
          })
        },2600)
      }).
      catch((err) => {
        console.log(err)
      })
    
  }

  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({
      [name] :  value
    })

  }




  

  componentWillMount =  () => {
   this.getAccountNames()
   this.specialAccount();
   this.getAllClassNames();
   this.getBanks();
  }

 
  render() {
    const toto = {
      "int" : this.state.accountNames,
      "abc" : this.state.specialAccount

    }
    console.log(this.state.dataValue)
    const { dataValue } = this.state;
    const option = toto[dataValue];

    console.log(this.state.data)
    const options = {
      filterType: "dropdown",
      responsive: "scroll"
     
    };
    const classNames = this.state.classNames.map((cd) => {
    
      return(
        <option value="abc">{cd.className}</option>
      )
     
    })

    const AccNames = this.state.accountNames.map((cd) => {
    
      return(
        <option>{cd.accountName}</option>
      )
     
    })

    const banks = this.state.bankNames.map((cd) => {
      return(
        <option>{cd.bankName}</option>
      )
    })

    let outerArray = [];
    let innerArray= [];
    this.state.data.forEach(res => {
      let jsObjs = res;
      innerArray = [];
      innerArray.push(jsObjs.accountName);
      innerArray.push(jsObjs.componentName);
      innerArray.push(jsObjs.componentDesc);
      innerArray.push(jsObjs.componentBalance);
      innerArray.push(jsObjs.componentSide);
      innerArray.push(jsObjs.bank);
      outerArray.push(innerArray);
    });

    

    
   
    return (
      <>
        <div className="mt-5 pt-1">
        <Helmet><title>ByteProof Components</title></Helmet>
              <Card className="card-stats">
                <CardBody>
                  <Row >
                    <Col md="12">
                      <div className="d-flex justify-content-between align-items-center">
                        <p className="text-info pt-1 pl-3"><a href="/admin/dashboard">Proof Dashboard</a> / <span>ByteProof Component</span></p> 
                        <div className="d-flex justify-content-end">
                      <Button color="info" size="sm" onClick={this.toggle}>Search Component <span className="fa fa-search"></span></Button>
                      <Button color="dark" size="sm" onClick={this.toggle2}>Create Component <span className="fa fa-plus"></span></Button>
                      </div>
                     </div>
                   </Col>
                   <Col>
                    
                   </Col>
                 </Row>
               </CardBody>
             </Card>
     {this.state.apiStatus &&
          <MuiThemeProvider theme={this.getMuiTheme()}>
         <MUIDataTable
         title={"byteproof component list"}
         data={outerArray}
         columns={compoSearch}
         options={options}
         />
          </MuiThemeProvider>
     }

                   
             
            

          <div>
          <Modal
          title="Search ByteProof Component"
          visible={this.state.modal3}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          footer={null}
        >
          <Form>
      <FormGroup>
        <Label for="exampleSelect">Select Class</Label>
        <Input type="select" id="exampleSelect" onChange={this.compChange}>
       
        <option value="int">*</option>
        {classNames}
         
        </Input>


      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Select Account</Label>
        <Input type="select" name="selectedAccount" id="exampleSelect" onChange={this.onChange}>
        <option></option>
        {this.state.dataValue && option.map(o => <option key={o.accountName} value={o.accountName}>{o.accountName}</option>)}
        </Input>
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Select Status</Label>
        <Input type="select" name="select" id="exampleSelect" onChange={this.onChange}>
          <option></option>
          <option>Active</option>
          <option>Inactive</option>
          <option>Pending</option>
        </Input>
      </FormGroup>
      {this.state.status ?  <button className ="btn btn-danger btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
       Serching ByteProof Component...
    </button> :
     <Button onClick={this.compoSearch}  color="dark btn-block">Search</Button>
    }
      </Form>
        </Modal>



        <Modal
          title="Create ByteProof Component"
          visible={this.state.createModal}
          onOk={this.handleOk2}
          onCancel={this.handleCancel2}
          footer={null}
        >
        <Form>
      <FormGroup>
        <Label for="exampleEmail">Component Name</Label>
        <Input type="email" name="componentname" id="exampleEmail" onChange={this.onChange} />
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Component Description</Label>
        <Input type="email" name="componentdescription" id="exampleEmail" onChange={this.onChange} />
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Component Balance</Label>
        <Input type="email" name="componentbalance" id="exampleEmail" onChange={this.onChange} />
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Account Name</Label>
        <Input type="select" name="accountname" id="exampleSelect" onChange={this.onChange}>
          <option></option>
        {AccNames}
          
        </Input>
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Component Side</Label>
        <Input type="select" name="componentside" id="exampleSelect" onChange={this.onChange}>
          <option></option>
          <option>Internal</option>
          <option>External</option>
          
        </Input>
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Bank</Label>
        <Input type="select" name="bank" id="exampleSelect" onChange={this.onChange}>
          <option></option>
          {banks}
        </Input> 
             </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Created By</Label>
        <Input type="email" name="created" id="exampleEmail" onChange={this.onChange} />
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Updated By</Label>
        <Input type="email" name="updated" id="exampleEmail" onChange={this.onChange} />
      </FormGroup>
      {this.state.status2 ?  <button className ="btn btn-danger btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
       Creating Byteproof Component...
    </button> :
     <Button onClick={this.compoCreate}  color="dark btn-block">CREATE BYTEPROOF COMPONENT</Button>
    }
      </Form>
        </Modal>
     
    </div>
         
          
         
        </div>
      </>
    );
  }
  dataSet = [
    ["Direct Payment Recievable_A", "DP Recievable_A","Holds The Component Side A","0.00", "Internal","Zenith"],
    ["Direct Payment Recievable_B", "DP Recievable_B","Holds The Component Side B","0.00", "External","Zenith"],
    
];
}

export default GLRComponents;
