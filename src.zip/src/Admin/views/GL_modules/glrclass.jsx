import React from "react";
import { Modal } from 'antd';
import ClassAlertSuccess from '../../Alerts/Success/class'
import {Card,CardHeader,CardBody,CardFooter,CardTitle,Row,Button,Form, FormGroup, Label, Input, FormText,Col,CardText,UncontrolledAlert, } from "reactstrap";
import logo2 from "../../assets/img/zen.jpeg";
import { dashboard24HoursPerformanceChart, dashboardEmailStatisticsChart,dashboardNASDAQChart} from "../../variables/charts";
import Header from '../../components/Navbars/DemoNavbar'
import MUIDataTable from "mui-datatables";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import axios from 'axios';
import {columnsSearchClass, columnsaddClass  } from '../../module_columns/class';
import classnames from 'classnames';
import { Helmet } from 'react-helmet'
class GLRClass extends React.Component {

  state = {
    modal: false,
    createModal: false,
    show: false,
    data:[],
    status: false,
    active: false,
    select: '',
    groupname: '',
    groupList : [],
    groupnameErr: false,
    classstatus: '',
    classstatusErr: false,
    message: '',
    status2: '',
    message2: '',
    bpgroupname:'',
    bpdesc:'',
    bpclass:'',
    createdby: '',
    matching:'',
    classStatus: '',
    apiStatus: false,
    apiStatus2: false,
    classData: [],
    msg: false,
    bill: true,
    apiError: false
  }
  componentWillMount = () => {
   
   this.groupApi();
  }
  // refresh = () => {
  //   axios.get(`http://localhost:13006/api/byteproof/v1/class/getclass?groupname=Prudential Zenith NIG.&classstatus=Active&page=0&size=10`,{
  //     auth: {
  //       username: 'ByteClient2',
  //       password: 'Password'
  //     }
  //   }).
  //   then((res)=> {
  //     console.log(res.data)
  //     console.log('testing')
  //     console.log('api')
  //     this.setState({
  //       classData: res.data.result
  //     }) 
  //   }).
  //   catch((err) => {
  //     console.log(err)
  //   })

  // }
  groupApi = () => {
    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpgroup/getAllGroupNames`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
      this.setState({
        groupList: res.data
      }) 
    }).
    catch((err) => {
    
    })
  }

handleCancel = e => {
  console.log(e);
  this.setState({
    modal: false, status: false
  });


 
};

handleOk2 = e => {
  console.log(e);
  this.setState({
    createModal: false,
  });
};

handleCancel2 = e => {
  console.log(e);
  this.setState({
    createModal: false,
  });
};

  getMuiTheme = () => createMuiTheme({
    overrides: {
      MUIDataTableHeadCell: {
        fixedHeaderOptions: {
          backgroundColor: `blue !important`,
        }
      },
      MUIDataTableHead: {
        root: {
          backgroundColor: `#1D252D !important` ,

        }
      },
      MUIDataTableBodyRow: {
        root: {
          '&:nth-child(odd)': { 
            backgroundColor: '#e3e9ed',
            data: {
              whiteSpace: 'nowrap'
            }
            
          }
        }
      },
      MuiTableCell: {
        root: {
            padding: '3px 3px 0 0'
        },
        body: {
            fontSize: '13px',
            textAlign: 'left'
        }
    },

      MUIDataTableSelectCell: {
        headerCell: {
          backgroundColor: '#000'
        },
        checked: `lightcoral !important`
      },
      MUIDataTablePagination: {
        root: {
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center"
        },
        caption: {
          fontSize: 12
        }
      }
    }
  })

  toggle = (e) => {
    e.preventDefault();
    this.setState({
      modal: !this.state.modal, show: true
    })
  }

    toggle2 = (e) => {
      e.preventDefault();
      this.setState({
        createModal: !this.state.createModal
      })
  }

  validateSearch = () => {
    let groupnameErr = false;
    let classstatusErr = false;
    if(!this.state.groupname){
      groupnameErr = true
    }
    if(!this.state.classstatus){
      classstatusErr = true
    }
    if(groupnameErr){
      this.setState({
        groupnameErr, classstatusErr
      })
      setTimeout(()=>{
        this.setState({
          classstatusErr: false, groupnameErr: false
        })

      },500)
      return false;
    }
   
  
    return true;
  }

  classSearch = (e) => {
    e.preventDefault();
    const classData = {
      groupname: this.state.groupname,
      classstatus: this.state.classstatus
    }
    const isValid = this.validateSearch();
    if(isValid){
      this.setState({
        status: true
      })
      axios.get(`http://34.246.178.255:13006/api/byteproof/v1/class/getclass?groupname=${this.state.groupname}&classstatus=${this.state.classstatus}`,{
        auth: {
          username: 'ByteClient2',
          password: 'Password'
        }
      }).
      then((res)=> {
        console.log(res.data)
        this.setState({
          status: false, data: res.data.result, message: res.data.message, modal: false, apiStatus: res.data.status, apiStatus2: false,bill: false
        }) 
      }).
      catch((err) => {
        console.log(err)
        this.setState({
          apiError: true
        })
        setTimeout(()=> {
          this.setState({
            apiError: false
          })
        },2000)
        
      })

    }
    else{
      this.setState({
        error: true
      })
      setTimeout(()=>{
        this.setState({
          error: false
        })
      },1000)
    }
  }

  classCreate = (e) => {
    e.preventDefault();
    const classData = {
      groupname: this.state.bpgroupname,
      classstatus: this.state.classStatus,
      classname: this.state.bpclass,
      classdescription: this.state.bpdesc,
      createdBy: this.state.createdby,
      classAutoMatching: this.state.matching,
    }
    console.log(classData)
    if(classData.groupname && classData.classstatus && classData.classname && classData.classdescription && classData.classAutoMatching && classData.createdBy){
      this.setState({
        status2: true
      })
      axios.post(`http://34.246.178.255:13006/api/byteproof/v1/class/create`,classData,{
        auth: {
          username: 'ByteClient2',
          password: 'Password'
        }
      }).
      then((res)=> {
        console.log(res.data)
        this.setState({
          status2: false, createModal: false, apiStatus2: res.data.status, msg: true, apiStatus: false,bill: false
        })
        this.refresh();
        setTimeout(()=>{
          this.setState({
            msg: false
          })
        },2600)
      }).
      catch((err) => {
        console.log(err)
      })

    }
    else{
      this.setState({
        error: true
      })
      setTimeout(()=>{
        this.setState({
          error: false
        })
      },1000)
    }
  }


  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({
      [name] :  value
    })

  }

  render() {
    let outerArray = [];
    let innerArray= [];
    this.state.data.forEach(res => {
      let jsObjs = res;
      innerArray = [];
      innerArray.push(jsObjs.groupName);
      innerArray.push(jsObjs.className);
      innerArray.push(jsObjs.classStatus);
      innerArray.push(jsObjs.classDescription);
      innerArray.push(jsObjs.classAutoMatching);
      outerArray.push(innerArray);
    });

    let outerArray2 = [];
    let innerArray2= [];
    this.state.classData.forEach(res => {
      let jsObjsa = res;
      innerArray2 = [];
      innerArray2.push(jsObjsa.groupName);
      innerArray2.push(jsObjsa.className);
      innerArray2.push(jsObjsa.classStatus);
      innerArray2.push(jsObjsa.classDescription);
      innerArray2.push(jsObjsa.classAutoMatching);
      outerArray2.push(innerArray2);
    });
    

    // const groupActions = this.state.groupList.map((grouplist)=>{
    //   return(
    //     <div>
    //      <option>{grouplist.accountName}</option>
    //     </div>
      
    //   )
      
    // })
    const options = {
      filterType: "dropdown",
      responsive: "scroll",
    }; 
    const opt = this.state.groupList.map((cd) => {
      console.log(cd.groupName)
      return(
        <option>{cd.groupName}</option>
      )
     
    })
    console.log(this.state.groupname)
    return (
      <>
        <div className="mt-5 pt-1">
        <Helmet><title>ByteProof Classes</title></Helmet>
              <Card className="card-stats">
                <CardBody>
                  <Row >
                    <Col md="12">
                      <div className="d-flex justify-content-between align-items-center">
                        <p className="text-info pt-1 pl-2"><a href="/admin/dashboard">Proof Dashboard</a> / <span>ByteProof Class</span></p> 
                        <div className="d-flex justify-content-end">
                        <Button color="info" size="sm" onClick={this.toggle}>Search Class <span className="mt-1 fa fa-search"></span></Button>
                       <Button color="danger" size="sm" onClick={this.toggle2}>Create Class <span className="mt-1 fa fa-plus"></span></Button>
                        </div>
                      </div>
                    </Col>
                    <Col>
                     
                    </Col>
                  </Row>
                </CardBody>
              </Card>
        {this.state.msg && <ClassAlertSuccess /> }
        {this.state.apiStatus &&
         <MuiThemeProvider theme={this.getMuiTheme()}>
         <MUIDataTable
         title={"byteproof class list"}
         data={outerArray}
         columns={columnsSearchClass}
         options={options}
         />
          </MuiThemeProvider>
        }
        {this.state.apiStatus2 &&
         <MuiThemeProvider theme={this.getMuiTheme()}>
         <MUIDataTable
         title={"byteproof class list"}
         data={outerArray2}
         columns={columnsaddClass}
         options={options}
         />
          </MuiThemeProvider>
        }
      
          
          <div>
          <Modal
          title="Search ByteProof Class"
          visible={this.state.modal}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          footer={null}
        >
          <div>
          <Form>
      <FormGroup>
      <Label for="exampleEmail">BP GroupName</Label>
      {this.state.groupnameErr ?
      <Input type="select" name="groupname" className="error" id="exampleEmail" onChange={this.onChange} >
          <option></option>
          {opt}
   
      </Input> :
       <Input type="select" name="groupname" id="exampleEmail" onChange={this.onChange} >
       <option></option>
       {opt}
      </Input>
     
      }
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Select Class Status</Label>
        {this.state.classstatusErr ? 
        <Input type="select" name="classstatus" className="error" onChange={this.onChange}  id="exampleSelect">
          <option></option>
          <option>Active</option>
          <option>Inactive</option>
          <option>Pending</option>
        </Input>
        :
        <Input type="select" name="classstatus" onChange={this.onChange}  id="exampleSelect">
        <option></option>
          <option>Active</option>
          <option>Inactive</option>
          <option>Pending</option>
        </Input>
  }
      </FormGroup>
     {this.state.status ?  <button className ="btn btn-danger btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
       Serching ByteProof Class...
    </button> :
     <Button onClick={this.classSearch}  color="dark btn-block">SEARCH BYTEPROOF CLASS</Button>
    }
      </Form>
          </div>
        </Modal>
        <Modal
          title="Create ByteProof Class"
          visible={this.state.createModal}
          onOk={this.handleOk2}
          onCancel={this.handleCancel2}
          footer={null}
        >
          <div>
          <Form>
      <FormGroup>
        <Label for="exampleEmail">BP ClassName</Label>
        {this.state.error ? <Input type="text" name="bpclass" id="exampleEmail" className="error"  onChange={this.onChange}  />:
      <Input type="text" name="bpclass" id="exampleEmail" onChange={this.onChange} />
      }
    
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Class Description</Label>
        {this.state.error ?   <Input type="text" name="bpdesc" className="error" id="exampleEmail" onChange={this.onChange}   />:
          <Input type="text" name="bpdesc" id="exampleEmail" onChange={this.onChange}   />
        }
      </FormGroup>
      
      <FormGroup>
        <Label for="exampleEmail">Created By</Label>
      {this.state.error ?  <Input type="number" name="createdby" className="error" id="exampleEmail"  onChange={this.onChange}  />:
       <Input type="number" name="createdby" id="exampleEmail"  onChange={this.onChange}  />
    }
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">GroupName</Label>
        {this.state.error ?       <Input type="text" name="bpgroupname" className="error" id="exampleEmail"  onChange={this.onChange}  /> :
             <Input type="text" name="bpgroupname" id="exampleEmail"  onChange={this.onChange}  />
      }
     
      </FormGroup>
      <FormGroup>
 
        <Label for="exampleEmail">Class AutoMatching</Label>
        {this.state.error ?    <Input type="select" name="matching" className="error" onChange={this.onChange} id="exampleSelect" >
         <option></option>
           <option>Y</option>
           <option>N</option>
         </Input>:
            <Input type="select" name="matching" onChange={this.onChange} id="exampleSelect" >
            <option></option>
              <option>Y</option>
              <option>N</option>
            </Input>
         }
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Class Status</Label> 
        {this.state.error ?  <Input type="select" name="classStatus" className="error" onChange={this.onChange} id="exampleSelect" >
         <option></option>
           <option>Active</option>
           <option>Inactive</option>
           <option>Pending</option>
         </Input>:
          <Input type="select" name="classStatus" onChange={this.onChange} id="exampleSelect" >
          <option></option>
            <option>Active</option>
            <option>Inactive</option>
            <option>Pending</option>
          </Input>     
        }
      </FormGroup>  
     {this.state.status2 ?  <button className ="btn btn-danger btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
       Creating ByteProof Class...
    </button> :
     <Button onClick={this.classCreate}  color="dark btn-block">CREATE BYTEPROOF CLASS</Button>
    }
      </Form>
          </div>
        </Modal>
    </div>   
        </div>
      </>
    );
  }
}
export default GLRClass;