
import React from "react";
// react plugin used to create charts
import { Line, Pie,Bar,Radar ,Doughnut} from "react-chartjs-2";
// reactstrap components
import axios from 'axios'
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Button,
  Form, FormGroup, Label, Input, FormText,CardText,UncontrolledAlert,
  Col
 
} from "reactstrap";
import { Helmet } from 'react-helmet'
// core components
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import {
  dashboard24HoursPerformanceChart,
  dashboardEmailStatisticsChart,


  dashboardNASDAQChart
} from "../../variables/charts.jsx";
import { Modal } from 'antd';
import Header from '../../components/Navbars/DemoNavbar';
import {columnAddAccount, columnSearchAccount} from '../../module_columns/account'
import MUIDataTable from "mui-datatables";

class GLRAccounts extends React.Component {
  state = {
    modal: false,
    createModal: false,
    status : false,
    grouplist: [],
    bpclassName: '',
    accountStatus: '',
    apiStatus:false,
    message: '',
    bpAname:'',
    bpClass: '',
    bpdesc:'',
    bpnum:'',
    bpAname: '',
    updated: '',
    created: '',
    currency: '',
    loadable: '',
    selectAccount:'',
    data: [],
    classData : [],
    status2: false,
    bill: true,
    msg: false
  } 
  

  toggle = (e) => {
    e.preventDefault();
    this.setState({
      modal: !this.state.modal
    })
  }

  handleOk = e => {
    console.log(e);
    this.setState({
      modal: false,
    });
  };

  handleCancel = e => {
    console.log(e);
    this.setState({
      modal: false,status:false
    });
  };

  
  handleOk = e => {
    console.log(e);
    this.setState({
      modal: false,
    });
  };

  handleCancel2 = e => {
    console.log(e);
    this.setState({
      createModal: false,
    });
  };

  accountSearch = (e) => {
    e.preventDefault();
    const accountData = {
      groupname: this.state.groupname,
      classstatus: this.state.classstatus
    }
    if(this.state.bpclassName && this.state.accountStatus){
      this.setState({
        status: true
      })
      axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpaccount/getBpAccount?classname=${this.state.bpclassName}&accountstatus=${this.state.accountStatus}&page=0&size=10`,{
        auth: {
          username: 'ByteClient2',
          password: 'Password'
        }
      }).
      then((res)=> {
        console.log(res.data)
        this.setState({
          status: false, data: res.data.result, message: res.data.message, modal: false, apiStatus: res.data.status, bill:false, apiStatus2: false
        }) 
      }).
      catch((err) => {
     
      })

    }
    else{
      this.setState({
        error: true
      })
      setTimeout(()=>{
        this.setState({
          error: false
        })
      },1000)
    }
  }

  accountCreate = (e) => {
    e.preventDefault();
   
    const accountData = {
      accountname: this.state.bpAname,
      accountnumber:this.state.bpnum,
      accountdesc: this.state.bpdesc,
      accountstatus: this.state.selectAccount,
      accountcurrency:this.state.currency,
      accountdatafilesloadable : this.state.loadable,
      createdBy: this.state.created,
      updatedBy: this.state.updated,
      classname: this.state.bpClass
    }
    console.log(accountData)
    if(accountData.accountname && accountData.accountnumber && accountData.accountdesc && accountData.accountstatus && accountData.accountcurrency && accountData.accountdatafilesloadable  && accountData.createdBy  && accountData.updatedBy  && accountData.classname){
      this.setState({
        status2: true
      })
      axios.post(`http://34.246.178.255:13006//api/byteproof/v1/bpaccount/create`,accountData,{
        auth: {
          username: 'ByteClient2',
          password: 'Password'
        }
      }).
      then((res)=> {
        console.log(res.data)  
        this.setState({
          status2: false, createModal:false, apiStatus2: res.data.status,  bill: false, msg: true
        })
        setTimeout(()=>{
          this.setState({
            msg: false
          })
        },2600)
      }).
      catch((err) => {
        console.log(err)
      })
    }
    else{
      this.setState({
        error: true
      })
      setTimeout(()=>{
        this.setState({
          error: false
        })
      },1000)
    }
  }

  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({
      [name] :  value
    })

  }


  componentWillMount = () => {
    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/class/getAllClassNames`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
      console.log(res.data)
      this.setState({
        classData: res.data
      }) 
    }).
    catch((err) => {
    
    })
   
  }

  getMuiTheme = () => createMuiTheme({
    overrides: {
      MUIDataTableHeadCell: {
        fixedHeaderOptions: {
          backgroundColor: `blue !important`,
        }
      },
      MUIDataTableHead: {
        root: {
          backgroundColor: `#1D252D !important` ,

        }
      },
      MUIDataTableBodyRow: {
        root: {
          '&:nth-child(odd)': { 
            backgroundColor: '#e3e9ed',
            data: {
              whiteSpace: 'nowrap'
            }
            
          }
        }
      },
      MuiTableCell: {
        root: {
            padding: '3px 3px 0 0'
        },
        body: {
            fontSize: '13px',
            textAlign: 'left'
        }
    },
      MUIDataTableSelectCell: {
        headerCell: {
          backgroundColor: '#000'
        },
        checked: `lightcoral !important`
      },
      MUIDataTablePagination: {
        root: {
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center"
        },
        caption: {
          fontSize: 12
        }
      }
    }
  })

    toggle2 = (e) => {
      e.preventDefault();
      this.setState({
        createModal: !this.state.createModal
      })

  }

  render(){
  console.log(this.state.data)

  const options = {
    filterType: "dropdown",
    responsive: "scroll",
    setRowProps: (row) => {
      return {
        style: {whiteSpace: 'nowrap', textAlign:'center'}
      };
    },
   
  };
  let outerArray = [];
  let innerArray= [];
  this.state.data.forEach(res => {
    let jsObjs = res;
    innerArray = [];
    innerArray.push(jsObjs.className);
    innerArray.push(jsObjs.accountName);
    innerArray.push(jsObjs.accountNumber);
    innerArray.push(jsObjs.accountDescription);
    innerArray.push(jsObjs.accountStatus);

    innerArray.push(jsObjs.accountCurrency);
    innerArray.push(jsObjs.accountDataFilesLoadable);
    outerArray.push(innerArray);
  });

 
const opt = this.state.classData.map((cd) => {
  return(
    <option>{cd.className}</option>

  )
 
})
console.log(opt)
    return (
      <>
        <div className="mt-5 pt-1">
        <Helmet><title>ByteProof Accounts</title></Helmet>
       
              <Card className="card-stats">
                <CardBody>
                  <Row >
                    <Col md="12">
                      <div className="d-flex justify-content-between align-items-center">
                        <p className="text-info pt-1 pl-3"><a href="/admin/dashboard">Proof Dashboard </a>/ <span>ByteProof Account</span></p> 
                        <div className="d-flex justify-content-end">
                      <Button color="info" size="sm" onClick={this.toggle}>Search Account <span className="fa fa-search"></span></Button>
                      <Button color="dark" size="sm" onClick={this.toggle2}>Create Account <span className="fa fa-plus"></span></Button>
                       <Button color="danger" size="sm">Bulk Account Create <span className="fa fa-plus-circle"></span></Button>
                       </div>
                      </div>
                    </Col>
                    <Col>
                     
                    </Col>
                  </Row>
                </CardBody>
              </Card>
              
        {this.state.apiStatus &&  
        <MuiThemeProvider theme={this.getMuiTheme()}>
         <MUIDataTable
         title={"Byteproof account list"}
         data={outerArray}
         columns={columnSearchAccount}
         options={options}
         />
          </MuiThemeProvider>
  }



          <div>
          <Modal
          title="Search ByteProof Account"
          visible={this.state.modal}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          footer={null}
        >
         <Form>
      <FormGroup>
        <Label for="exampleEmail">BP ClassName</Label>
        {this.state.error ?
        <Input type="select" name="bpclassName" className="error" id="exampleEmail" onChange={this.onChange}>
                <option></option>
          {opt}
        </Input>:
          <Input type="select" name="bpclassName" id="exampleEmail" onChange={this.onChange}>
          <option></option>
          {opt}
          </Input>
        }
        

      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Select Account Status</Label>
        <Input type="select" name="accountStatus" id="exampleSelect" onChange={this.onChange}>
        <option></option>
          <option>Active</option>
          <option>InActive</option>
          <option>Pending</option>
         
        </Input>
      </FormGroup>
      {this.state.status ?  <button className ="btn btn-danger btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
       Secrhing ByteProof Account...
    </button> :
     <Button onClick={this.accountSearch}  color="dark btn-block">SEARCHING BYTEPROOF ACCOUNT</Button>
    }
      </Form>

          
        </Modal>
        <Modal
          title="Create ByteProof Account"
          visible={this.state.createModal}
          onOk={this.handleOk2}
          onCancel={this.handleCancel2}
          footer={null}
        >
         <Form>
      <FormGroup>
        <Label for="exampleEmail">BP Account Name</Label>
        {this.state.error ?  <Input type="text" name="bpAname" className="error" id="exampleEmail" onChange={this.onChange} />:
         <Input type="text" name="bpAname" id="exampleEmail" onChange={this.onChange} />
      }
        
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">BP Account Number</Label>
        {this.state.error ? <Input type="text" name="bpnum" id="exampleEmail" className="error" onChange={this.onChange} /> :
        <Input type="text" name="bpnum" id="exampleEmail" onChange={this.onChange} />
       }
      
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">BP Account Description</Label>
        {this.state.error ?  <Input type="text" name="bpdesc" className="error" id="exampleEmail" onChange={this.onChange} />: 
       <Input type="text" name="bpdesc" id="exampleEmail" onChange={this.onChange} />
      }
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Select Account Status</Label>
        {this.state.error ?  <Input type="select" name="selectAccount" id="exampleSelect" className="error" onChange={this.onChange}>
          <option></option>
          <option>Active</option>
          <option>Inactive</option>
          <option>Pending</option>
        </Input>:
       <Input type="select" name="selectAccount" id="exampleSelect" onChange={this.onChange}>
       <option></option>
       <option>Active</option>
       <option>Inactive</option>
       <option>Pending</option>
     </Input>
      
      }
       
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Select BP ClassName</Label>
        {this.state.error ?   <Input type="select" name="bpClass" className="error" id="exampleSelect" onChange={this.onChange}>
        <option></option>
       {opt}
        </Input>:
       <Input type="select" name="bpClass" id="exampleSelect" onChange={this.onChange}>
       <option></option>
      {opt}
       </Input>
      }
       
  
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Account DataFiles Loadable</Label>
        {this.state.error ?     <Input type="number" name="loadable" className="error" id="exampleEmail" onChange={this.onChange}/>:
         <Input type="text" name="loadable" id="exampleEmail" onChange={this.onChange}/>
      }
       
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Select Account Currency</Label>
        {this.state.error ? 
        <Input type="select" name="currency" id="exampleSelect" className="error" onChange={this.onChange}>
          <option></option>
          <option>NGN</option>
          <option>USD</option>
         
        </Input>:
         <Input type="select" name="currency" id="exampleSelect" onChange={this.onChange}>
         <option></option>
         <option>NGN</option>
         <option>USD</option>
        
       </Input>

        }
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Created By</Label>
        {this.state.error ? <Input type="text" name="created" className="error" id="exampleEmail" onChange={this.onChange} /> :
      <Input type="number" name="created" id="exampleEmail" onChange={this.onChange} />
      }
        
      </FormGroup>
      <FormGroup>
        <Label for="exampleEmail">Updated By</Label>
        {this.state.error ?    <Input type="text" name="updated" id="exampleEmail" className="error" onChange={this.onChange} />:
         <Input type="number" name="updated" id="exampleEmail" onChange={this.onChange} />
      }
     
      </FormGroup>    
      {this.state.status2 ?  <button className ="btn btn-danger btn-block" type="button">
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
       Creating BP Account...
    </button> :
     <Button onClick={this.accountCreate}  color="dark btn-block">CREATE BYTEPROOF ACCOUNT</Button>
    }
      </Form>
      
          
        </Modal>
     
       
       
      
    </div>
         
          
         
        </div>
      </>
    );
  }
  dataSet = [
    ["Direct Payment", "Direct Pay-ment Recievable","0012345678","Holds Direct Payment Recievable Transaction", "Active","NGN", 2],
  




    
];
}

export default GLRAccounts;
