import React from 'react'
class Childoptions extends React.Component{
  child = (e) => {
      e.preventDefault()
      alert('click')
  }
    render(){
        console.log(this.props)
        return(
            <>
            <option><li>ss</li></option>
            </>
        )
    }
}


export default Childoptions