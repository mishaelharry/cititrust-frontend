import React, { Component } from 'react';

import ContextMenuTrigger from '../layouts/ContextMenuTrigger';
import ContextMenu from '../layouts/ContextMenu';
import MenuItem from '../layouts/MenuItem';
import '../layouts/react-contextmenu.css'
const MENU_TYPE = 'SIMPLE';

export default class Maps extends Component {
    constructor(props) {
        super(props);

        this.state = { logs: [], visible: false };
    }

    handleClick = (e, data) => {
       
    }

    onClick =(e) => {
      e.preventDefault();
      this.setState({
        visible: !this.state.visible
      })

    }

    render() {
        return (
            <div>
              <br />
              <br />
              <br />
              <br />
              <br />
              <div><button className="btn btn-sm btn-info" onClick={this.onClick}>click</button></div>
              {this.state.visible &&
              <div>
                
                <a href="#"><ContextMenuTrigger id={MENU_TYPE} holdToDisplay={1000} >
                    <div className='well'>right click to see the menu</div>
                </ContextMenuTrigger></a>
                <div>
                    {this.state.logs.map((log, i) => <p key={i}>{log}</p>)}
                </div>
                <ContextMenu id={MENU_TYPE}>
                    <MenuItem onClick={this.handleClick} data={{ item: 'item 1' }}>View</MenuItem>
                    <MenuItem onClick={this.handleClick} data={{ item: 'item 2' }}>Match</MenuItem>
                    <MenuItem onClick={this.handleClick} data={{ item: 'item 2' }}>Unmatch</MenuItem>
                    <MenuItem divider />
                    <MenuItem onClick={this.handleClick} data={{ item: 'item 3' }}>Goto group</MenuItem>
                </ContextMenu>
    
            </div>
    }
            </div>
        );
    }
}
