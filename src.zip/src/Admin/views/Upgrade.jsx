import React from 'react';
import axios from 'axios'
const lookup = {
  "int": [
    { id: '1', text: '1' },
    { id: '2', text: '2' },
    { id: '3', text: '3' },
    { id: '4', text: '4' },
    { id: '5', text: '5' }
  ],
  "abc": [
    { id: 'a', text: 'a' },
    { id: 'b', text: 'b' },
    { id: 'c', text: 'c' },
    { id: 'd', text: 'd' },
    { id: 'e', text: 'e' }
  ]
}

class Upgrade extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataValue: 'int',
      gen:[],
      spe:[]
    }
  }

  componentWillMount = () =>{
    this.getclassNames()
    this.specialAccount();
  }

  getclassNames = () => {

    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpaccount/getAllAccountNames`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
      console.log(res.data)
      this.setState({
        gen: res.data
      }) 
    }).
    catch((err) => {
    
    })
  }

  
  specialAccount =() => {
    
    axios.get(`http://34.246.178.255:13006/api/byteproof/v1/bpaccount/getAllAccountNamesByClass?classname=Verve Receivable`,{
      auth: {
        username: 'ByteClient2',
        password: 'Password'
      }
    }).
    then((res)=> {
      console.log(res.data)
      this.setState({
        spe: res.data
      }) 
    }).
    catch((err) => {
    
    })

  }

 o
  render() {
    const toto = {
      "int" : this.state.gen,
      "abc" : this.state.spe,
   

    }
    console.log(this.state.dataValue)
    const { dataValue } = this.state;
    const options = lookup[dataValue];
    return (
      <div className="text-center">
      <br />
      <br />
      <br />
      <br />
      <br />
        <select onChange={this.onChange}>
        <option></option>
       
          <option value="int">Integers</option>
          <option value="abc">Alphabets</option>
        </select>
        <hr />
        <select>
         <option>choose</option>
          <p onClick={this.alert}>{options.map(o => <option key={o.id} value={o.id}>{o.id}</option>) }</p>
        </select>
      </div>
    );
  }
}
export default Upgrade