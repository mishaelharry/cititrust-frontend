export const columnSearchAccount = [
    {
        name: "Class Name",
        options: {
          filter: true,
          setCellHeaderProps: (value) => {
            return {
             
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
                }
            };
          },
  
        }
      },
      {
  
        name: "Account Name",
        options: {
          filter: true,
          setCellHeaderProps: (value) => {
            return {
             
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
                }
            };
          }
        }
      },
      {
  
        name: "Account Number",
        options: {
          filter: true,
          setCellHeaderProps: (value) => {
            return {
             
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
                }
            };
          }
        }
      },
      {
        name: "Account Description",
        options: {
          filter: false,
          setCellHeaderProps: (value) => {
            return {
             
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
                }
            };
          }
        }
      },
      {
        name: "Account Status",
        options: {
          filter: true,
          setCellHeaderProps: (value) => {
            return {
             
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
          
                }
            };
          }
        }
      },
      {
        name: "Currency",
        options: {
          filter: true,
          setCellHeaderProps: (value) => {
            return {
            
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
                }
            };
          },
          sort: false,
        }
      },
      {
        name: "DataLoadablFile",
        options: {
          filter: true,
          setCellHeaderProps: (value) => {
            return {
             
                style: {
                  backgroundColor: '#000',
                  
                  whiteSpace: 'pre',
                  color: 'white'
                }
            };
          },
          sort: false,
        }
      },
      
      
      
     
    ];

    
  
    export const columnAddAccount = [
        {
            name: "Class Name",
            options: {
              filter: true,
              setCellHeaderProps: (value) => {
                return {
                 
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
                    }
                };
              },
      
            }
          },
          {
      
            name: "Account Name",
            options: {
              filter: true,
              setCellHeaderProps: (value) => {
                return {
                 
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
                    }
                };
              }
            }
          },
          {
      
            name: "Account Number",
            options: {
              filter: true,
              setCellHeaderProps: (value) => {
                return {
                 
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
                    }
                };
              }
            }
          },
          {
            name: "Account Description",
            options: {
              filter: false,
              setCellHeaderProps: (value) => {
                return {
                 
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
                    }
                };
              }
            }
          },
          {
            name: "Account Status",
            options: {
              filter: true,
              setCellHeaderProps: (value) => {
                return {
                 
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
              
                    }
                };
              }
            }
          },
          {
            name: "Currency",
            options: {
              filter: true,
              setCellHeaderProps: (value) => {
                return {
                
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
                    }
                };
              },
              sort: false,
            }
          },
          {
            name: "DataLoadablFile",
            options: {
              filter: true,
              setCellHeaderProps: (value) => {
                return {
                 
                    style: {
                      backgroundColor: '#000',
                      
                      whiteSpace: 'pre',
                      color: 'white'
                    }
                };
              },
              sort: false,
            }
          },
          
          
          
      ];
    
      
   